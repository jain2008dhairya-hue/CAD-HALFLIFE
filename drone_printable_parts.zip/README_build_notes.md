# 3-inch stabilized quad: CAD and build notes

All dimensions in mm. Z is up, X runs front/back along the battery, arms sit at 45 degrees. Origin is the centre of the bottom plate's underside.

## What is in this folder

| File | What it is |
|---|---|
| `stabilized_drone_assembly.step` | Full assembly: 4 printed arms, 2 plates, 4 legs, IMU tray, ESP32 deck, plus reference motors, props, battery, ESC, ESP32 and IMU/baro boards. Import into Onshape (Import > STEP). |
| `printable_parts/*.stl` and `.step` | The six unique printed parts, each in print orientation. `x4` means print 4. |
| `images/` | Iso, exploded, side, top and a dimensioned layout drawing. |
| `source/build_drone.py` | The parametric script that generated everything (needs `pip install cadquery`). |

Printed parts: bottom plate x1, top plate x1, arm x4, leg x4, IMU tray x1 (print in TPU or use foam), ESP32 deck x1.

## Key dimensions

| Item | Value |
|---|---|
| Motor-to-motor (diagonal) | 150 mm, motors at (+/-53.03, +/-53.03) |
| Prop | 3-inch, 76 mm; gap between neighbouring props about 30 mm |
| Plates | 84 x 56 x 3 mm, corners filleted R8, then scalloped by a 76 mm circle around each motor so the plate stays out from under the props |
| Arm | 12 wide x 4.5 thick, runs from r = 19 to the motor axis at r = 75; motor pad diameter 22 |
| Arm rib | 2 wide x 3 tall on top, r = 42 to 64 |
| Arm clamp bolts | 2x M3 per arm at r = 24 and r = 33 (through bottom plate, arm, top plate) |
| Motor holes | 4x M2 on a 12 x 12 pattern, plus a 6 mm centre hole (check your motor's pattern) |
| Stack holes | 20 x 20 M3 at the centre |
| Wire pass-through | 12 x 12 square in the middle of both plates |
| Strap slots | 3 x 14 at x = +/-39 in the bottom plate |
| Leg | diameter 9 x 34 long, at r = 48 under each arm, M3 heat-set insert in the top |
| Height stack | bottom plate 0-3, arms 3-7.5, top plate 7.5-10.5, posts 6, ESC, posts 6, ESP32 deck |
| Battery | 72 x 35 x 24 mm hangs 3.5 mm below the bottom plate (room for nuts and bolt heads) |

Checked in the model: no part overlaps except the intended motor-shaft/prop hub contact, props clear all other parts by at least 9 mm, and all printed STLs are watertight.

## Weight

Printed parts total about 52 cm3, roughly 29-39 g in PETG depending on infill. With 4 motors (about 40 g), ESC, ESP32, sensors, props, a 3S 1000 mAh battery and wiring, expect about 200 g, under 250 g.

## Hardware you will need besides the BOM parts

- 8x M3 x 12 bolts + 8 nuts (arm clamps), nylon nuts or thread-lock
- 4x M3 x 10 bolts + 4 M3 heat-set inserts (legs)
- 8x M3 standoffs, 6 mm (two sets of four for the stack)
- 4x M3 screws for the stack, length to suit
- 4x M2 x 6 screws for the IMU tray plus small rubber grommets or foam tape
- Motor screws (usually included with the motors)
- A 10-12 mm wide battery strap

## Recreating it in Onshape (so you own the design)

1. **Variables** (Part Studio, Variables feature): wheelbase = 150, plateL = 84, plateW = 56, plateT = 3, armW = 12, armT = 4.5, armStart = 19, padD = 22, propD = 76, motorPattern = 12. Motor offset = wheelbase / 2 / sqrt(2) = 53.03.
2. **Bottom plate:** sketch on the Top plane, centred 84 x 56 rectangle, fillet R8, extrude 3. Sketch the 20 x 20 stack holes (3.2 dia), the centre 12 x 12 cut, and the two slots at x = +/-39 (3 x 14). Add the arm-bolt holes by drawing a 45-degree construction line, placing holes at 24 and 33 along it, and using a Circular Pattern of 4 about the origin. Finish with a cut: a 76 mm circle at each motor position (53.03, 53.03), through the plate.
3. **Top plate:** same sketch, extruded from an offset plane at 7.5, minus the strap slots, plus four 2.6 mm holes at (-38 and -26, +/-4.5) for the IMU tray.
4. **Arm (its own Part Studio):** sketch a 12-wide rectangle on the X axis from x = 19 to x = 75, add a 22 mm circle at x = 75, extrude 4.5. Add the rib (x 42-64, 2 wide, 3 tall) on top. Holes: 3.2 mm at x = 24, 33, 48; four 2.2 mm at (75 +/- 6, +/-6); one 6 mm at x = 75.
5. **Leg:** 9 mm cylinder, 34 long, 4 mm blind hole 8 deep in the top.
6. **Assembly:** insert the plates, 4 arms (rotate 45, 135, 225, 315 degrees about Z, sitting at z = 3), 4 legs, then run the interference check. Import `stabilized_drone_assembly.step` into a second tab to overlay and compare.

## Printing

- Material: PETG or ASA. Not PLA (brittle, softens in a warm car or sun).
- 0.2 mm layers, 4 walls, about 40% gyroid infill, no supports needed.
- Arms flat with the rib up. Plates flat. Legs standing up.
- IMU tray in TPU, or PETG with soft grommets. Its job is to keep motor vibration away from the IMU.

## Assumptions to verify against your actual parts

- Motor mounting pattern (12 x 12 M2 here) and shaft/prop fit.
- 4-in-1 ESC board size and hole pattern (modelled as 28 x 28 on a 20 x 20 stack).
- Battery size (modelled 72 x 35 x 24 mm); edit the battery box and the strap slots in `source/build_drone.py` if yours differs.
- ESP32-S3 board size (modelled 52 x 25.5); the deck is 56 x 30 and the board attaches with tape or zip ties.
- 3-inch prop diameter (76 mm). 3040 and 3028 props are close; check yours.
